
public class iPhone implements AppleStoreUnit
{

    public void produce()
    {
        System.out.println("Product available: iPhone");

    }

}
