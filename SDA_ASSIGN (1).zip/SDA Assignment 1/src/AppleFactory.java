public class AppleFactory extends AppleAbstract
{
    public AppleStoreUnit getProduct(String productType)
    {
            if(productType.equals("IPHONE")){
                return new iPhone();
            } else if (productType.equals("IPAD")){
                return new iPad();
            }
        return null;
    }
}
