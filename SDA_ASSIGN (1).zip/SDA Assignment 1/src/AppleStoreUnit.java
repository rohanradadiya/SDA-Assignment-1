public interface AppleStoreUnit
{
    void produce();
}
