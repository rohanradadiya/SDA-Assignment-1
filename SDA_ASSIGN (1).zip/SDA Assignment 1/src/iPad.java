
public class iPad implements AppleStoreUnit
{
    private static final String FILENAME = "/C:\\Users\\100698109\\IdeaProjects\\SDA Assignment 1\\src\\applestoreunitdata.xml";
        public void produce()
        {
            System.out.println("Product available: iPad");
        }
}
