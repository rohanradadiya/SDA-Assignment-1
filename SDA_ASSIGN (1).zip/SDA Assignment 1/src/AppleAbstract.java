public abstract class AppleAbstract {
    abstract AppleStoreUnit getProduct(String productType);
}
