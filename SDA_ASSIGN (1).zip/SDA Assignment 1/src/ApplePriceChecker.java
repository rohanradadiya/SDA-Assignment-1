import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class ApplePriceChecker extends AppleFactoryDemoTest {
    private static final String FILENAME = "/C:\\Users\\100698109\\IdeaProjects\\SDA Assignment 1\\src\\applestoreunitdata.xml";

    public static void main(String[] args) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(FILENAME));

            System.out.println("Root Element:" + doc.getDocumentElement().getNodeName());
            System.out.println("-------");

            NodeList list = doc.getElementsByTagName("appleproducts");

            for (int temp = 0; temp < list.getLength(); temp++) {

                Node node = list.item(temp);

                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    String id = element.getAttribute("product");

                    String name = element.getElementsByTagName("name").item(0).getTextContent();
                    String price = element.getElementsByTagName("price").item(0).getTextContent();

                    System.out.println("Product :" + name);
                    System.out.println("Price:" + price);
                }
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
        }
    }
}
